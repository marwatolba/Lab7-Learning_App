import 'package:assignment3/family_member.dart';
import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Color(0xffe97918),
          title: Center(
            child: Text(
              'Language Learning App ',
            ),
          ),
        ),
        body: ListView(children: [
          SizedBox(
            height: 10,
          ),
          Center(
            child: Text(
              "Your Way TO Learn Japanese ",
              style: TextStyle(
                color: Color(0xffb04619),
                fontSize: 25,
                fontWeight: FontWeight.bold,
                fontStyle: FontStyle.italic,
              ),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Card(
            color: Color(0xffe947cc),
            child: ListTile(
              onTap: (() {
                // Navigator.of(context).push(MaterialPageRoute(
                //   builder: (BuildContext context) => Novels()));
              }),
              title: Text('Numbers',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
              //subtitle: Text('Outher'),
              trailing: Icon(Icons.numbers),
            ),
          ),
          Card(
            color: Color(0xff2763ef),
            child: ListTile(
              onTap: (() {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (BuildContext context) => family_mem()));
              }),
              title: Text(
                'Family Members',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
              ),
              // subtitle: Text('Outher'),
              trailing: Icon(Icons.family_restroom),
            ),
          ),
          Card(
            color: Color(0xff2e9c33),
            child: ListTile(
              onTap: (() {
                // Navigator.of(context).push(MaterialPageRoute(
                // builder: (BuildContext context) => Notepad()));
              }),
              title: Text('Colors',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
              //subtitle: Text('Outher'),
              trailing: Icon(Icons.color_lens),
            ),
          ),
          Image.asset(
            'assets/image/learning.png',
            height: 400,
          ),
        ]));
  }
}
