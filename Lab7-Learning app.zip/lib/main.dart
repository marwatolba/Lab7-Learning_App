import 'package:assignment3/family_member.dart';
import 'package:assignment3/homepage.dart';
import 'package:flutter/material.dart';

main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: HomePage(),
  ));
}
